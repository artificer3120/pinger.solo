"""
Pinger — test control panel for Pingle notifications + Mini-Mac.

Buttons:
  - Ping: fires a randomized test notification with droid chirp
  - Mini-Mac: launches the retro-mac desktop ornament
  - Stop Mini-Mac: kills it
"""

import sys
import os
import random
import subprocess
import signal
import winsound
import threading
import webbrowser
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton,
    QHBoxLayout, QVBoxLayout, QGraphicsOpacityEffect,
    QSizePolicy,
)
from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QCursor, QLinearGradient, QColor, QPainter

# Win95 palette
W95_SURFACE = "#c0c0c0"
W95_BTN_HIGHLIGHT = "#ffffff"
W95_BTN_FACE = "#dfdfdf"
W95_BTN_SHADOW = "#808080"
W95_FRAME = "#0a0a0a"
W95_TITLE_BLUE = "#000080"
W95_TITLE_BLUE_LIGHT = "#1084d0"
W95_TEXT = "#000000"
W95_FONT = "MS Sans Serif"
QB_URL = "https://questboard-ec2.tail7f6073.ts.net"

RETRO_MAC_PATH = os.path.join(os.path.expanduser("~"), "dev", "retro-mac", "retro_mac.pyw")
SCROLLSTACK_PATH = os.path.join(os.path.expanduser("~"), "forge3", "scrollstack", "scrollstack.py")

# Random test pings
TEST_PINGS = [
    ("Zug Zug! Job Done!", "Blocked"),
    ("The forge grows quiet...", "Blocked"),
    ("Picass0 rendered your portrait", "Blocked"),
    ("Agent down! Sindri needs help", "Blocked"),
    ("New quest on the board!", "Blocked"),
    ("Pebble is buzzing", "Blocked"),
    ("EC2 instance needs attention", "Blocked"),
    ("LoRA training complete", "Blocked"),
    ("Deployment finished — verify", "Blocked"),
    ("Artificer, your attention please", "Blocked"),
]


def droid_chirp():
    """R2-D2 style chirp in background thread."""
    import time
    def _chirp():
        patterns = [
            [(1200, 80), (800, 120), (1600, 60), (1000, 100), (1400, 150)],
            [(900, 100), (1300, 70), (700, 130), (1500, 90), (1100, 110)],
            [(1400, 60), (1000, 80), (1800, 50), (600, 140), (1200, 100)],
        ]
        beeps = random.choice(patterns)
        for freq, dur in beeps:
            winsound.Beep(freq, dur)
            time.sleep(0.05)
    threading.Thread(target=_chirp, daemon=True).start()


def win95_raised():
    return (
        f"border-top: 2px solid {W95_BTN_HIGHLIGHT};"
        f"border-left: 2px solid {W95_BTN_HIGHLIGHT};"
        f"border-right: 2px solid {W95_FRAME};"
        f"border-bottom: 2px solid {W95_FRAME};"
    )


def win95_sunken():
    return (
        f"border-top: 2px solid {W95_FRAME};"
        f"border-left: 2px solid {W95_FRAME};"
        f"border-right: 2px solid {W95_BTN_HIGHLIGHT};"
        f"border-bottom: 2px solid {W95_BTN_HIGHLIGHT};"
    )


def win95_btn_style():
    return f"""
        QPushButton {{
            background: {W95_SURFACE};
            color: {W95_TEXT};
            font-family: "{W95_FONT}", Arial, sans-serif;
            font-size: 11px;
            padding: 4px 12px;
            {win95_raised()}
        }}
        QPushButton:hover {{
            background: {W95_BTN_FACE};
        }}
        QPushButton:pressed {{
            {win95_sunken()}
            padding: 5px 11px 3px 13px;
        }}
    """


class PingleNotification(QWidget):
    active = []
    queue = []
    MAX_VISIBLE = 3
    WIDTH = 440
    HEIGHT = 165
    MARGIN = 16
    GAP = 8
    DISPLAY_MS = 15000
    FADE_MS = 500

    def __init__(self, ticket_id, title, action_text, action_color="#a05a3a", url=None):
        super().__init__()
        self.ticket_id = ticket_id
        self.url = url or f"{QB_URL}/ticket/{ticket_id}"
        self.slot = None

        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
            | Qt.Tool | Qt.WindowDoesNotAcceptFocus
        )
        self.setFixedSize(self.WIDTH, self.HEIGHT)

        # Outer frame
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        container = QWidget()
        container.setObjectName("win95frame")
        container.setStyleSheet(f"#win95frame {{ background: {W95_SURFACE}; {win95_raised()} }}")
        outer_layout.addWidget(container)

        main_layout = QVBoxLayout(container)
        main_layout.setContentsMargins(3, 3, 3, 3)
        main_layout.setSpacing(0)

        # Title bar
        titlebar = QWidget()
        titlebar.setFixedHeight(22)
        tb_layout = QHBoxLayout(titlebar)
        tb_layout.setContentsMargins(4, 2, 2, 2)
        tb_layout.setSpacing(4)

        tb_title = QLabel(f"Questboard | #{ticket_id}")
        tb_title.setFont(QFont(W95_FONT, 9, QFont.Bold))
        tb_title.setStyleSheet("color: #fff; background: transparent;")
        tb_layout.addWidget(tb_title)
        tb_layout.addStretch()

        close_btn = QPushButton("X")
        close_btn.setFixedSize(16, 14)
        close_btn.setCursor(QCursor(Qt.PointingHandCursor))
        close_btn.setFont(QFont(W95_FONT, 7, QFont.Bold))
        close_btn.setStyleSheet(f"""
            QPushButton {{ background: {W95_SURFACE}; color: {W95_TEXT}; {win95_raised()} padding: 0; font-size: 8px; }}
            QPushButton:pressed {{ {win95_sunken()} }}
        """)
        close_btn.clicked.connect(self.dismiss)
        tb_layout.addWidget(close_btn)
        main_layout.addWidget(titlebar)

        # Body
        body_frame = QWidget()
        body_frame.setStyleSheet(f"background: {W95_SURFACE}; margin: 4px;")
        body_layout = QVBoxLayout(body_frame)
        body_layout.setContentsMargins(8, 6, 8, 4)
        body_layout.setSpacing(4)

        heading = QLabel(f"#{ticket_id} | {action_text}")
        heading.setFont(QFont(W95_FONT, 11, QFont.Bold))
        heading.setStyleSheet(f"color: {W95_TEXT}; background: transparent;")
        body_layout.addWidget(heading)

        body = QLabel(title)
        body.setFont(QFont(W95_FONT, 10))
        body.setStyleSheet(f"color: {W95_TEXT}; background: transparent;")
        body.setWordWrap(True)
        body_layout.addWidget(body)
        body_layout.addStretch()
        main_layout.addWidget(body_frame, 1)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(4, 0, 4, 4)
        btn_row.setSpacing(6)
        btn_row.addStretch()

        open_btn = QPushButton("Open Ticket")
        open_btn.setCursor(QCursor(Qt.PointingHandCursor))
        open_btn.setFixedSize(100, 23)
        open_btn.setFont(QFont(W95_FONT, 9))
        open_btn.setStyleSheet(win95_btn_style())
        open_btn.clicked.connect(self.open_ticket)
        btn_row.addWidget(open_btn)

        dismiss_btn = QPushButton("Dismiss")
        dismiss_btn.setCursor(QCursor(Qt.PointingHandCursor))
        dismiss_btn.setFixedSize(100, 23)
        dismiss_btn.setFont(QFont(W95_FONT, 9))
        dismiss_btn.setStyleSheet(win95_btn_style())
        dismiss_btn.clicked.connect(self.dismiss)
        btn_row.addWidget(dismiss_btn)
        btn_row.addStretch()
        main_layout.addLayout(btn_row)

        # Opacity for fade
        self.opacity_effect = QGraphicsOpacityEffect(self)
        self.opacity_effect.setOpacity(1.0)
        self.setGraphicsEffect(self.opacity_effect)

        # Auto-dismiss
        self.dismiss_timer = QTimer(self)
        self.dismiss_timer.setSingleShot(True)
        self.dismiss_timer.timeout.connect(self.fade_out)
        self.dismiss_timer.start(self.DISPLAY_MS)

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        gradient = QLinearGradient(3, 3, self.width() - 3, 3)
        gradient.setColorAt(0, QColor(W95_TITLE_BLUE))
        gradient.setColorAt(1, QColor(W95_TITLE_BLUE_LIGHT))
        painter.fillRect(3, 3, self.width() - 6, 22, gradient)
        painter.end()

    def show_in_slot(self, slot):
        self.slot = slot
        cursor_screen = QApplication.screenAt(QCursor.pos())
        if cursor_screen is None:
            cursor_screen = QApplication.primaryScreen()
        screen = cursor_screen.availableGeometry()
        x = screen.right() - self.WIDTH - self.MARGIN
        y = screen.top() + self.MARGIN + slot * (self.HEIGHT + self.GAP)
        self.move(x, y)
        self.show()
        self.raise_()
        self.activateWindow()
        droid_chirp()

    def fade_out(self):
        self.anim = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.anim.setDuration(self.FADE_MS)
        self.anim.setStartValue(1.0)
        self.anim.setEndValue(0.0)
        self.anim.setEasingCurve(QEasingCurve.OutQuad)
        self.anim.finished.connect(self.dismiss)
        self.anim.start()

    def dismiss(self):
        self.dismiss_timer.stop()
        if self in PingleNotification.active:
            PingleNotification.active.remove(self)
            self._reflow()
            self._process_queue()
        self.close()
        self.deleteLater()

    def open_ticket(self):
        webbrowser.open(self.url, new=0)
        self.dismiss()

    @classmethod
    def send(cls, ticket_id, title, action_text, action_color="#a05a3a"):
        notif = cls(ticket_id, title, action_text, action_color)
        if len(cls.active) < cls.MAX_VISIBLE:
            slot = len(cls.active)
            cls.active.append(notif)
            notif.show_in_slot(slot)
        else:
            cls.queue.append(notif)

    @classmethod
    def _reflow(cls):
        for i, notif in enumerate(cls.active):
            notif.show_in_slot(i)

    @classmethod
    def _process_queue(cls):
        while cls.queue and len(cls.active) < cls.MAX_VISIBLE:
            notif = cls.queue.pop(0)
            slot = len(cls.active)
            cls.active.append(notif)
            notif.show_in_slot(slot)


class PingerPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pinger")
        self.setFixedSize(430, 50)
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.setStyleSheet(f"background: {W95_SURFACE}; {win95_raised()}")
        self.counter = 900
        self.minimac_proc = None
        self.scrollstack_proc = None

        # auto-position: center-bottom of primary work area (excludes taskbar)
        import ctypes.wintypes
        rect = ctypes.wintypes.RECT()
        ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(rect), 0)
        work_w = rect.right - rect.left
        work_h = rect.bottom - rect.top
        x = rect.left + (work_w - self.width()) // 2
        y = rect.top + work_h - self.height()
        self.move(x, y)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        ping_btn = QPushButton("Ping!")
        ping_btn.setCursor(QCursor(Qt.PointingHandCursor))
        ping_btn.setFont(QFont(W95_FONT, 10, QFont.Bold))
        ping_btn.setStyleSheet(win95_btn_style())
        ping_btn.clicked.connect(self.fire_ping)
        layout.addWidget(ping_btn)

        mac_btn = QPushButton("Mini-Mac")
        mac_btn.setCursor(QCursor(Qt.PointingHandCursor))
        mac_btn.setFont(QFont(W95_FONT, 10, QFont.Bold))
        mac_btn.setStyleSheet(win95_btn_style())
        mac_btn.clicked.connect(self.start_minimac)
        layout.addWidget(mac_btn)

        stop_btn = QPushButton("Stop Mini-Mac")
        stop_btn.setCursor(QCursor(Qt.PointingHandCursor))
        stop_btn.setFont(QFont(W95_FONT, 10, QFont.Bold))
        stop_btn.setStyleSheet(win95_btn_style())
        stop_btn.clicked.connect(self.stop_minimac)
        layout.addWidget(stop_btn)

        ss_btn = QPushButton("scrollstack()")
        ss_btn.setCursor(QCursor(Qt.PointingHandCursor))
        ss_btn.setFont(QFont(W95_FONT, 10, QFont.Bold))
        ss_btn.setStyleSheet(win95_btn_style())
        ss_btn.clicked.connect(self.toggle_scrollstack)
        layout.addWidget(ss_btn)
        self.ss_btn = ss_btn

    def fire_ping(self):
        self.counter += 1
        title, action = random.choice(TEST_PINGS)
        PingleNotification.send(
            ticket_id=self.counter,
            title=title,
            action_text=action,
        )

    def start_minimac(self):
        if self.minimac_proc and self.minimac_proc.poll() is None:
            return  # already running
        self.minimac_proc = subprocess.Popen(
            ["pythonw", RETRO_MAC_PATH],
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )

    def stop_minimac(self):
        if self.minimac_proc and self.minimac_proc.poll() is None:
            self.minimac_proc.terminate()
            self.minimac_proc = None

    def toggle_scrollstack(self):
        if self.scrollstack_proc and self.scrollstack_proc.poll() is None:
            # running — kill it
            self.scrollstack_proc.terminate()
            self.scrollstack_proc = None
            self.ss_btn.setText("scrollstack()")
        else:
            # not running — start it
            self.scrollstack_proc = subprocess.Popen(
                ["python", SCROLLSTACK_PATH,
                 "--zone", "left_third",
                 "--display", "1",
                 "--class", "CASCADIA",
                 "--scroll-from", "center_third"],
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
            )
            self.ss_btn.setText("stop scrollstack")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    panel = PingerPanel()
    panel.show()
    sys.exit(app.exec_())
