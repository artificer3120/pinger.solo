---
title: Pinger Rebuild — UntitledSDK First Tool Prototype
version: 0.1
operator: Artificer
agent: sindri
timestamp: 1777255000
---

# Pinger Rebuild Plan

## Goal

Rebuild Pinger using UntitledSDK components. Produce a working desktop widget AND a Visualiz3r mockup. This proves the SDK can build real tools, not just heartBeat demos.

## Deliverables

1. **Visualiz3r mockup** — `visualiz3r/development/pinger-sdk.json` + generated HTML
2. **GridSmith schematic** — Pinger widget anatomy in the Widgets platform
3. **Desktop shell** — `shells/desktop/pinger.py` using SDK base classes
4. **.widgetTree doc** — `documentation/pinger/pinger.widgetTree.md`

## Build Steps

### Phase 1 — SDK Frameless Visual Base (core work)
- [ ] Add `BarWidget` class to `shells/desktop/` — frameless visual widget, no titlebar, no body. Just a styled container with a horizontal element layout.
- [ ] Extract Win95 styling constants to `core/styles.py` — shared between heartBeat and Pinger
- [ ] Add `SDKButton` element class to `elements/button.py` — Win95 raised button with label, click handler

### Phase 2 — Pinger Widget
- [ ] Build `shells/desktop/pinger.py` — BarWidget with 4 SDKButtons: Ping, Mini-Mac, Stop Mini-Mac, scrollstack()
- [ ] Wire click handlers: notification fire, subprocess launch/kill
- [ ] Test on desktop — confirm it matches original Pinger behavior

### Phase 3 — Visualiz3r Artifact
- [ ] Write `visualiz3r/development/pinger-sdk.json` — viz.py JSON spec for the Pinger bar
- [ ] Generate HTML: `python viz.py generate development/pinger-sdk.json`
- [ ] Open in Min for visual review

### Phase 4 — GridSmith + Documentation
- [ ] Add Pinger to widgetTemplates in GridSmith
- [ ] Write `documentation/pinger/pinger.widgetTree.md`

## Pinger widgetTree.DOM (target)

```
pinger.bar
  ├─ pinger.bar.button.1.label("Ping!")
  ├─ pinger.bar.button.2.label("Mini-Mac")
  ├─ pinger.bar.button.3.label("Stop Mini-Mac")
  └─ pinger.bar.button.4.label("scrollstack()")
```

## Pinger widgetTree.stateMap

| State | Description |
|-------|-------------|
| idle | All buttons default |
| minimac.running | Mini-Mac button pressed, Stop visible |
| scrollstack.running | scrollstack button text changes to "stop scrollstack" |

## File Structure After Build

```
dev/untitledSDK/
  core/
    styles.py          ← NEW: shared Win95 constants
  elements/
    button.py          ← NEW: SDKButton element
  shells/desktop/
    bar.py             ← NEW: BarWidget base (frameless visual)
    pinger.py          ← NEW: Pinger implementation
    widget.py          ← existing heartBeat shell
  documentation/
    pinger/
      pinger.widgetTree.md  ← NEW
```
