"""
UntitledSDK — pinger (radix shell)

Test control panel for Pingle notifications + Mini-Mac + scrollStack + snap.region.
Built on iE.baseFrame() with theme=radix.

Usage:
    python pinger.py
    pythonw pinger.py    # background
"""

import sys
import os
import random
import subprocess
import winsound
import threading

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton,
    QHBoxLayout, QVBoxLayout, QFrame,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon

from core.base_frame import BaseFrame
from core.themes import get_theme

__version__ = "1.0.0"

QB_URL = "https://questboard-ec2.tail7f6073.ts.net"
LOCALMESH_URL = "http://127.0.0.1:8801"
RETRO_MAC_PATH = os.path.join(os.path.expanduser("~"), "dev", "retro-mac", "retro_mac.pyw")
SCROLLSTACK_PATH = os.path.join(os.path.expanduser("~"), "forge3", "scrollstack", "scrollstack.py")
ICON_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".design", "icons", "pinger.ico")
SHAREX = r"C:\Program Files\ShareX\ShareX.exe"

TEST_PINGS = [
    "Zug Zug! Job Done!",
    "The forge grows quiet...",
    "Picass0 rendered your portrait",
    "Agent down! Sindri needs help",
    "New quest on the board!",
    "Pebble is buzzing",
    "EC2 instance needs attention",
    "LoRA training complete",
    "Deployment finished — verify",
    "Artificer, your attention please",
]


def droid_chirp(low=False):
    """Play a randomized chirp pattern. low=True for HALT (lower freq)."""
    def _chirp():
        import time
        if low:
            beeps = [(400, 120), (300, 140), (200, 160)]
        else:
            patterns = [
                [(1200, 80), (800, 120), (1600, 60), (1000, 100), (1400, 150)],
                [(900, 100), (1300, 70), (700, 130), (1500, 90), (1100, 110)],
                [(1400, 60), (1000, 80), (1800, 50), (600, 140), (1200, 100)],
            ]
            beeps = random.choice(patterns)
        for freq, dur in beeps:
            try:
                winsound.Beep(freq, dur)
            except RuntimeError:
                pass
            time.sleep(0.05)
    threading.Thread(target=_chirp, daemon=True).start()


_T = get_theme("radix")


class RadixButton(QPushButton):
    """Padded radix button with semantic kinds."""

    KIND_STYLES = {
        "primary":   ("#3e63dd", "#fff", "#4f71e5"),
        "secondary": (_T.bg_alt, _T.text, _T.border),
        "danger":    (f"{_T.accent_red}22", _T.accent_red, f"{_T.accent_red}33"),
        "purple":    (f"{_T.accent_purple}22", _T.accent_purple, f"{_T.accent_purple}33"),
        "halt":      (f"{_T.accent_red}", "#fff", "#f56b6f"),
    }

    def __init__(self, text, kind="secondary", parent=None):
        super().__init__(text, parent)
        self._kind = kind
        bg, color, hover = self.KIND_STYLES[kind]
        border = _T.border_hi if kind in ("secondary",) else "transparent"
        self.setStyleSheet(f"""
            QPushButton {{
                background: {bg};
                color: {color};
                border: 1px solid {border};
                border-radius: 6px;
                padding: 10px 16px;
                font-family: {_T.font_family};
                font-size: 13px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background: {hover};
                color: {color if kind != "secondary" else _T.text};
            }}
            QPushButton:pressed {{
                padding: 11px 15px 9px 17px;
            }}
        """)
        self.setCursor(Qt.PointingHandCursor)


class Pinger(BaseFrame):
    """pinger — radix-shelled control panel for Pingle/Mini-Mac/scrollstack/snap."""

    def __init__(self):
        self.counter = 900
        self.minimac_proc = None
        self.scrollstack_proc = None
        self.halted = False

        super().__init__(app_name="pinger", default_pct=0.18, theme="radix")
        # title accessory: version badge — implemented via build_content (fr.fr1 inviolable)
        self._set_size_radix()
        self._auto_position()

    def _set_size_radix(self):
        # narrow widget per mockup; auto-fits content height
        self.setFixedWidth(560)

    def _auto_position(self):
        import ctypes.wintypes
        rect = ctypes.wintypes.RECT()
        ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(rect), 0)
        work_w = rect.right - rect.left
        work_h = rect.bottom - rect.top
        x = rect.left + (work_w - self.width()) // 2
        y = rect.top + work_h - self.sizeHint().height() - 8
        self.move(x, y)

    def build_content(self, layout):
        t = self.theme

        # ── fr2.appHeader: version badge (right of titlebar, in nav strip) ──
        nav = QFrame()
        nav.setStyleSheet(f"background: {t.bg_alt}; border-bottom: 1px solid {t.border};")
        nav_layout = QHBoxLayout(nav)
        nav_layout.setContentsMargins(12, 6, 12, 6)
        nav_layout.addStretch()
        version_badge = QLabel(f"v{__version__}")
        version_badge.setStyleSheet(
            f"background: {t.accent_blue}22; color: {t.accent_blue};"
            f"font-size: 10px; font-weight: 600; padding: 2px 8px; border-radius: 4px;"
        )
        nav_layout.addWidget(version_badge)
        layout.addWidget(nav)

        # ── 6-button surface: 2 rows × 3 buttons ──
        body = QFrame()
        body.setStyleSheet(f"background: {t.bg};")
        bv = QVBoxLayout(body)
        bv.setContentsMargins(12, 12, 12, 12)
        bv.setSpacing(8)

        # Row 1: Ping! / Mini-Mac / Stop Mini-Mac
        r1 = QHBoxLayout()
        r1.setSpacing(8)

        self.btn_ping = RadixButton("Ping!", kind="primary")
        self.btn_ping.clicked.connect(self.fire_ping)
        r1.addWidget(self.btn_ping)

        self.btn_minimac = RadixButton("Mini-Mac", kind="secondary")
        self.btn_minimac.clicked.connect(self.start_minimac)
        r1.addWidget(self.btn_minimac)

        self.btn_stop_mac = RadixButton("Stop Mini-Mac", kind="danger")
        self.btn_stop_mac.clicked.connect(self.stop_minimac)
        r1.addWidget(self.btn_stop_mac)

        bv.addLayout(r1)

        # Row 2: scrollstack() / snap.region() / HALT
        r2 = QHBoxLayout()
        r2.setSpacing(8)

        self.btn_ss = RadixButton("scrollstack()", kind="purple")
        self.btn_ss.clicked.connect(self.toggle_scrollstack)
        r2.addWidget(self.btn_ss)

        self.btn_snap = RadixButton("snap.region()", kind="secondary")
        self.btn_snap.clicked.connect(self.snap_region)
        r2.addWidget(self.btn_snap)

        self.btn_halt = RadixButton("HALT", kind="halt")
        self.btn_halt.setMinimumWidth(80)
        self.btn_halt.setMaximumWidth(100)
        self.btn_halt.clicked.connect(self.do_halt)
        r2.addWidget(self.btn_halt)

        bv.addLayout(r2)
        layout.addWidget(body)

        # ── status bar ──
        sf = QFrame()
        sf.setStyleSheet(f"background: {t.panel}; border-top: 1px solid {t.border};")
        sl = QHBoxLayout(sf)
        sl.setContentsMargins(14, 8, 14, 8)

        self.status_dot = QLabel("●")
        self.status_dot.setStyleSheet(f"color: {t.accent_green}; font-size: 8px;")
        sl.addWidget(self.status_dot)

        self.status_label = QLabel("ready -- all services nominal")
        self.status_label.setStyleSheet(f"color: {t.text_dim}; font-size: 11px;")
        sl.addWidget(self.status_label)
        sl.addStretch()

        self.mesh_label = QLabel("localMesh :8801")
        self.mesh_label.setStyleSheet(f"color: {t.text_dim}; font-size: 11px;")
        sl.addWidget(self.mesh_label)

        layout.addWidget(sf)

    # ── status helpers ──

    def _status(self, text, color=None):
        t = self.theme
        if color is None:
            color = t.accent_green
        self.status_dot.setStyleSheet(f"color: {color}; font-size: 8px;")
        self.status_label.setText(text)

    # ── actions ──

    def fire_ping(self):
        if self.halted:
            self._status("halted -- resume to send pings", self.theme.accent_red)
            return
        self.counter += 1
        title = random.choice(TEST_PINGS)
        droid_chirp()
        self._status(f"sent ping #{self.counter} -- {title}")

    def start_minimac(self):
        if self.minimac_proc and self.minimac_proc.poll() is None:
            return
        try:
            self.minimac_proc = subprocess.Popen(
                ["pythonw", RETRO_MAC_PATH],
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
            self._status("mini-mac running")
        except FileNotFoundError:
            self._status("mini-mac script not found", self.theme.accent_red)

    def stop_minimac(self):
        if self.minimac_proc and self.minimac_proc.poll() is None:
            self.minimac_proc.terminate()
            self.minimac_proc = None
            self._status("mini-mac stopped")
        else:
            self._status("mini-mac not running", self.theme.accent_yellow)

    def snap_region(self):
        if not os.path.exists(SHAREX):
            self._status("ShareX not installed", self.theme.accent_red)
            return
        try:
            subprocess.Popen([SHAREX, "-RectangleRegion"])
            self._status("snap.region() fired")
        except Exception as e:
            self._status(f"snap.region failed: {e}", self.theme.accent_red)

    def toggle_scrollstack(self):
        if self.scrollstack_proc and self.scrollstack_proc.poll() is None:
            self.scrollstack_proc.terminate()
            self.scrollstack_proc = None
            self.btn_ss.setText("scrollstack()")
            self._status("scrollstack stopped")
        else:
            try:
                self.scrollstack_proc = subprocess.Popen(
                    ["python", SCROLLSTACK_PATH,
                     "--zone", "left_third",
                     "--display", "1",
                     "--class", "CASCADIA",
                     "--scroll-from", "center_third"],
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                )
                self.btn_ss.setText("stop scrollstack")
                self._status("scrollstack active")
            except FileNotFoundError:
                self._status("scrollstack script not found", self.theme.accent_red)

    def do_halt(self):
        """HALT — POST /kill on localMesh per WO decision #1."""
        droid_chirp(low=True)
        try:
            import urllib.request
            req = urllib.request.Request(f"{LOCALMESH_URL}/kill", method="POST")
            urllib.request.urlopen(req, timeout=3)
            self.halted = True
            self._status("HALTED -- localMesh kill switch tripped", self.theme.accent_red)
            self.btn_halt.setText("RESUME")
            self.btn_halt.clicked.disconnect()
            self.btn_halt.clicked.connect(self.do_resume)
        except Exception as e:
            self._status(f"HALT failed: {e}", self.theme.accent_red)

    def do_resume(self):
        try:
            import urllib.request
            req = urllib.request.Request(f"{LOCALMESH_URL}/resume", method="POST")
            urllib.request.urlopen(req, timeout=3)
            self.halted = False
            self._status("resumed -- all services nominal")
            self.btn_halt.setText("HALT")
            self.btn_halt.clicked.disconnect()
            self.btn_halt.clicked.connect(self.do_halt)
        except Exception as e:
            self._status(f"resume failed: {e}", self.theme.accent_red)


def main():
    import ctypes
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("untitledSDK.pinger")

    app = QApplication(sys.argv)
    if os.path.exists(ICON_PATH):
        app.setWindowIcon(QIcon(ICON_PATH))
    pinger = Pinger()
    if os.path.exists(ICON_PATH):
        pinger.setWindowIcon(QIcon(ICON_PATH))
    pinger.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
